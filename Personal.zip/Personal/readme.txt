Thanks for downloading this theme!

Theme Name: Personal
Theme URL: https://bootstrapmade.com/personal-free-resume-bootstrap-template/
Author: BootstrapMade
Author URL: https://bootstrapmade.com